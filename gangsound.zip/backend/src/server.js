const cfg = require('./config');
const express = require('express'), http = require('http'), cors = require('cors'), helmet = require('helmet'), mongoose = require('mongoose');

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: cfg.cors === '*' ? true : cfg.cors.split(',') }));
app.use(express.json({ limit: '50kb' }));
app.get('/', (_q, r) => r.json({ ok: true, name: 'GangSound API' }));
app.use('/api', require('./routes'));

const server = http.createServer(app);
require('./sockets')(server, cfg);
mongoose.connect(cfg.mongo)
  .then(() => server.listen(cfg.port, () => console.log(`GangSound API on :${cfg.port}`)))
  .catch((e) => { console.error('Mongo failed:', e.message); process.exit(1); });
