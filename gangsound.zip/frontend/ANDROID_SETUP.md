# Android setup (after `flutter create`)
Add to android/app/src/main/AndroidManifest.xml, above <application>:

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>

Only while testing over plain http, add to <application ...>:  android:usesCleartextTraffic="true"

In android/app/build.gradle(.kts) set minSdk to 23 or higher.
Capturing *system* audio on Android uses screen capture (flutter_webrtc), follow the
"Android" notes in the flutter_webrtc README (foreground service) if you want that mode.
Microphone mode needs nothing extra.
